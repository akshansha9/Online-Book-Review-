Following are the files and folders used in this practice exercise. 

Code Snippet Folder: This folder contains all the code snippet to be used in this exercise. You can keep this on a location of your choice, make sure to provide correct path or change path while running code.

Oracle SQL: This file describes all the practice exercises and what is the task to be performed.